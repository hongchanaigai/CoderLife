#include <stdio.h>

int main(int argc, char *argv[]){
	printf("Hello world, this is a C program.\n");
	return 0;
}
