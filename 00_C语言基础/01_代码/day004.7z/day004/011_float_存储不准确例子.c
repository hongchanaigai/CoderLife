//011_float_存储不准确类型例子.c
#include <stdio.h>

int main(int argc, char *argv[]){
	float a = 100.9f;
	printf("%f\n", a);

	return 0;
}
