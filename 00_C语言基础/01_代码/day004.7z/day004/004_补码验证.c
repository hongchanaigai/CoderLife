//004_补码验证.c

#include <stdio.h>

int main(int argc, char *argv[]){
	char a = 0x81;
	printf("a = %d\n", a);

	char b = 0xe5;
	printf("b = %d\n", b);

	char c = 0x6f;
	printf("c = %d\n", c);

	char d = -123;
	printf("d = %x\n", d);

	return 0;
}
