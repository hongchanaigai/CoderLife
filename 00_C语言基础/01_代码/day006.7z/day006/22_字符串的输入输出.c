/**********************************************************
 * Author         : huang
 * Creat modified : 2020-07-20 22:01
 * Last modified  : 2020-07-20 22:01
 * Filename       : 22_字符串的输入输出.c
 * Description    : 
 * *******************************************************/

#include <stdio.h>

int main()
{
	char str[100];
	printf("please input string: ");
	scanf("%s", str);

	printf("str = %s\n", str);

	return 0;
}
