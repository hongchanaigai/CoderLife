//003_external.c

#include <stdio.h>

int main(){
	printf("this is an external program.\n");

	return 0;
}
