'''
实验 4.2 设计并编写带有界面的猜数游戏程序
使用python标准库或扩展库编写GUI版本的猜数游戏。
每次猜数之前要启动游戏并设置猜数范围和最大猜数次数等参数，退出游戏时显示战绩（共玩几次，猜对几次）信息。
'''
import random
import tkinter
from tkinter.messagebox import showerror, showinfo
from tkinter.simpledialog import askinteger

root = tkinter.Tk()#新建窗口
root.title("猜数游戏")#窗口标题
root.geometry("280x80+400+300")#窗口初始大小和位置
root.resizable(False, False)#不允许窗口改变大小

user_number = tkinter.StringVar(root, value="0")#用户猜的数
total_count = tkinter.IntVar(root, value="0")#允许猜的次数
already_count = tkinter.IntVar(root, value="0")#已经猜的次数
current_number = tkinter.IntVar(root, value="0")#当前生成的随机数
count = tkinter.IntVar(root, value="0")#玩家玩游戏的总次数
right_count = tkinter.IntVar(root, value="0")#玩家猜对的次数

lb = tkinter.Label(root, text= "请输入一个数：")#提示标签
lb.place(x=10, y=10, width=100, height=20)#提示标签的位置，大小

#玩家猜数并将该数输入到文本框
entry_number = tkinter.Entry(root, width=140, textvariable=user_number)
entry_number.place(x=110, y=10, width=140, height=20)
entry_number["state"] = "disabled"#默认为禁用模式，只有开始游戏后才允许输入

#单击按钮事件处理函数
def buttonClick():
    if button["text"] == "Start Game":
        #每次游戏允许玩家自定义数值范围，玩家需要输入正确的数
        #最小数
        while True:
            try:
                start = askinteger("允许输入的最小整数", "最小数（必须大于0）", initialvalue=1)
                if start != None:
                    assert  start > 0
                    break
            except:
                pass
        #最大数
        while True:
            try:
                end = askinteger("允许输入的最大整数", "最大数（必须大于10）", initialvalue=11)
                if end != None:
                    assert  end>10 and end>start
                    break
            except:
                pass

        current_number.set(random.randint(start, end))#在自定义的范围内生成要猜的随机数

        #玩家自定义允许猜几次，必须输入正确的整数
        while True:
            try:
                t = askinteger("最多允许猜几次？", "总次数（必须大于0）", initialvalue=3)
                if t != None:
                    assert t > 0
                    total_count.set(t)
                    break
            except:
                pass
        #已猜次数初始化为0
        already_count.set(0)
        button["text"] = "剩余次数：" + str(t)

        user_number.set(0)#文本框初始化为0
        entry_number["state"] = "normal"#启用文本框，允许用户输入
        count.set(count.get() + 1)#玩游戏的次数+1
    else:
        total = total_count.get()#一共允许猜的次数
        current = current_number.get()#本次游戏的正确答案
        #玩家本次猜的数
        try:
            x = int(user_number.get())
        except:
            showerror("抱歉", "必须输入整数")
            return
        #猜对
        if x == current:
            showinfo("恭喜", "猜对了")
            button["text"] = "Start Game"
            entry_number["state"] = "disabled"#禁用文本框
            right_count.set(right_count.get() + 1)#猜对次数+1
        else:
            already_count.set(already_count.get() + 1)#已猜次数+1
            if x>current:
                showerror("抱歉", "猜的数太大了")
            else:
                showerror("抱歉", "猜的数太小了")
        #可猜次数用完
        if already_count.get() == total:
            showerror("抱歉", "游戏结束，正确数为：" + str(current_number.get()))
            button["text"] = "Start Game"
            entry_number["state"] = "disabled"#禁用文本框
        else:
            button["text"] = "剩余次数：" + str(total-already_count.get())


#在窗口上创建按钮，并设置事件处理函数
button = tkinter.Button(root, text="Start Game", command=buttonClick)
button.place(x=10, y=40, width=250, height=20)

#关闭程序时提示战绩
def closeWindow():
    message = "共玩游戏{0}次，猜对{1}次！\n欢迎再次玩游戏！"
    message = message.format(count.get(), right_count.get())
    showinfo("战绩", message)
    root.destroy()

root.protocol("WM_DELETE_WINDOW", closeWindow)
root.mainloop()#启动消息主循环